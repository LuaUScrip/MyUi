# AntiGodHubUI

A simple compact Roblox UI library designed for clean feature panels.

## Included

- Title
- Section
- Toggle
- Button
- Divider
- Footer
- Value / TextBox
- Slider
- Dropdown
- Draggable window
- Minimize button

## Important Slider Behavior

The slider has a small editable value at the **top-right**, next to the slider title.

There is **no separate custom-value box underneath the slider**.

Example:

    Walk Speed                         100
    ━━━━━━━━━━━━━━━━━●━━━━━━━━━━━━━━

Tap `100` and type any value you want.

## Basic Usage

```lua
local UI = require(path.to.Library)

local Window = UI.new({
    Title = "AntiGodHub",
})

Window:Toggle({
    Name = "Example Toggle",
    Callback = function(enabled)
        print(enabled)
    end,
})

Window:Slider({
    Name = "Walk Speed",
    Min = 0,
    Max = 1000,
    Default = 100,
    Callback = function(value)
        print(value)
    end,
})

Window:Button({
    Text = "Inf Jump",
    Callback = function()
        print("Clicked")
    end,
})

Window:Divider()
Window:Footer("YouTube: AntiGodHub")
```

## GitHub Layout

```text
AntiGodHubUI/
├── src/
│   └── Library.lua
├── examples/
│   └── Example.lua
├── .github/
│   └── workflows/
└── README.md
```

The library does not contain game-specific feature logic. Add your own callbacks for the game/project you are building.
